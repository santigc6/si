-Ha de incluirse un "virtualenv" en el directorio "1401_Fernandez_Gonzalez-Carvajal" de nombre "si1pyenv" tal y como indican las instrucciones de plataforma (no se incluye en la entrega porque el zip supera el tamaño permitido). Este, se supone que usará Python 2.
-Acceder a http://localhost/~<usuario>/webflix.wsgi/ para el índice.

Autores: Adrián Fernández Amador y Santiago González- Carvajal Centera.
