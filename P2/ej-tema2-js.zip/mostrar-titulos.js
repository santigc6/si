function mostrarTitulos() {
     document.write("<H1><U>T�tulos</U><BR></H1>")
     for (i=1; i<=6; i++){
	document.write("<H" + i + ">T�tulo " + i)
	document.write("</H" + i + "><BR>")
     }
}
