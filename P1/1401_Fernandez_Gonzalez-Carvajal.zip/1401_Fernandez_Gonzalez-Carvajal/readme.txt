El diseño del sitio web y el mapa de navegación del mismo aparecen en el pdf Memoria-P1.pdf. Así mismo, indicamos las páginas a realizar, los ficheros y los enlaces entre páginas en el mismo pdf.

Autores: Adrián Fernández Amador y Santiago González- Carvajal Centenera.
