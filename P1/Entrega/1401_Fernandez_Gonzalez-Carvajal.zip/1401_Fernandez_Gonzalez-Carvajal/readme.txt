-El mapa de navegación y el diseño del sitio web se encuentran en la memoria.
-Para la navegación entre htmls hay que respetar la estructura interna de directorios (index.html, html, css, pics). Está preparado para funcionar en apache (además de localmente) si se quiere, respetando esta estructura.

Autores: Adrián Fernández Amador y Santiago González- Carvajal Centera.
